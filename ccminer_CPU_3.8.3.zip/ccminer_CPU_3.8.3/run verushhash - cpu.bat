@echo off
cd /d "%~dp0"
start "" /min ccminer.exe -a verus -o stratum+tcp://ap.luckpool.net:3956 -u RBYoNGAHE4TuEYTDqWhj9b5oKKU6RQcrjs.worker1 -p x -t 4